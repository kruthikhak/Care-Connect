# Care Connect - Hospital Directory

A web application that provides information about hospitals across various cities and states. Users can search, filter, and view detailed information about hospitals.

## Features

- Hospital search functionality
- Filtering by city, state, and rating
- User authentication with Google OAuth
- User dashboard with favorites and search history
- Responsive design using Bootstrap

## Prerequisites

- Node.js (v14+)
- MongoDB (local or Atlas)
- Google OAuth credentials

## Installation

1. Clone this repository:
```
git clone <repository-url>
cd care-connect
```

2. Install dependencies:
```
npm install
```

3. Create a `.env` file in the project root with the following variables:
```
GOOGLE_CLIENT_ID=your-google-client-id
GOOGLE_CLIENT_SECRET=your-google-client-secret
SESSION_SECRET=some-random-session-secret
BASE_URL=http://localhost:3001
MONGO_URI=your-mongodb-connection-string
```

4. To get Google OAuth credentials:
   - Go to the [Google Developer Console](https://console.developers.google.com/)
   - Create a new project
   - Go to "Credentials" and create OAuth 2.0 Client IDs
   - Set authorized redirect URIs to include `http://localhost:3001/auth/google/callback`
   - Copy the Client ID and Client Secret to your `.env` file

## Running the Application

1. Start the server:
```
npm start
```

2. For development (with auto-reload):
```
npm run dev
```

3. Access the application at `http://localhost:3001`

## Data Structure

The application uses a JSON file (`hospital_data.json`) to store hospital information in the following format:

```json
{
  "hospitals": [
    {
      "hospital_id": "1",
      "city": "Anantpur",
      "state": "Andhra Pradesh",
      "district": "Anantapur",
      "density": 213.34,
      "location": {
        "latitude": 14.6819,
        "longitude": 77.6006
      },
      "rating": 4.1,
      "review_count": 229
    },
    // More hospitals...
  ],
  "total_count": 2566
}
```

## Folder Structure

```
care-connect/
├── config/             # Configuration files
│   └── passport.js     # Passport.js configuration
├── middleware/         # Express middleware
│   └── auth.js         # Authentication middleware
├── models/             # MongoDB models
│   └── User.js         # User model
├── public/             # Static assets
│   ├── index.html      # Main hospital listing page
│   ├── login.html      # Login page
│   ├── signup.html     # Signup page
│   └── dashboard.html  # User dashboard
├── routes/             # Express routes
│   └── auth.js         # Authentication routes
├── .env                # Environment variables
├── convert_to_json.py  # Script to convert CSV to JSON
├── hospital_data.csv   # Source CSV data
├── hospital_data.json  # Processed JSON data
├── package.json        # Node.js dependencies
├── server.js           # Express server setup
└── README.md           # Project documentation
```

## License

MIT 