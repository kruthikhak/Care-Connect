const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Read hospital data
const hospitalData = JSON.parse(fs.readFileSync('hospital_data.json', 'utf8'));

// API Routes
app.get('/api/hospitals', (req, res) => {
    const { page = 1, limit = 20, city, state, minRating } = req.query;
    let filteredHospitals = [...hospitalData.hospitals];

    // Apply filters
    if (city) {
        filteredHospitals = filteredHospitals.filter(h => 
            h.city.toLowerCase().includes(city.toLowerCase())
        );
    }
    if (state) {
        filteredHospitals = filteredHospitals.filter(h => 
            h.state.toLowerCase().includes(state.toLowerCase())
        );
    }
    if (minRating) {
        filteredHospitals = filteredHospitals.filter(h => 
            h.rating >= parseFloat(minRating)
        );
    }

    // Pagination
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    const paginatedHospitals = filteredHospitals.slice(startIndex, endIndex);

    res.json({
        hospitals: paginatedHospitals,
        total_count: filteredHospitals.length,
        current_page: parseInt(page),
        total_pages: Math.ceil(filteredHospitals.length / limit)
    });
});

app.get('/api/hospitals/:id', (req, res) => {
    const hospital = hospitalData.hospitals.find(h => h.hospital_id === req.params.id);
    if (!hospital) {
        return res.status(404).json({ error: 'Hospital not found' });
    }
    res.json(hospital);
});

app.get('/api/stats', (req, res) => {
    const stats = {
        total_hospitals: hospitalData.total_count,
        states: [...new Set(hospitalData.hospitals.map(h => h.state))],
        cities: [...new Set(hospitalData.hospitals.map(h => h.city))],
        avg_rating: hospitalData.hospitals.reduce((acc, h) => acc + h.rating, 0) / hospitalData.total_count
    };
    res.json(stats);
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
