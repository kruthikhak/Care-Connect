const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const session = require('express-session');
const passport = require('passport');
const MongoStore = require('connect-mongo');

// Load config
dotenv.config({ path: './.env' });

// Passport config
require('./config/passport')(passport);

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Session middleware
app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  store: MongoStore.create({
    mongoUrl: process.env.MONGO_URI || 'mongodb://localhost:27017/care-connect'
  })
}));

// Passport middleware
app.use(passport.initialize());
app.use(passport.session());

// Read hospital data
const hospitalData = JSON.parse(fs.readFileSync('hospital_data.json', 'utf8'));

// Routes
// Auth routes
app.use('/auth', require('./routes/auth'));

// API Routes
app.get('/api/hospitals', (req, res) => {
    const { page = 1, limit = 20, city, state, minRating } = req.query;
    let filteredHospitals = [...hospitalData.hospitals];

    // Apply filters
    if (city) {
        filteredHospitals = filteredHospitals.filter(h => 
            h.city.toLowerCase().includes(city.toLowerCase())
        );
    }
    if (state) {
        filteredHospitals = filteredHospitals.filter(h => 
            h.state.toLowerCase().includes(state.toLowerCase())
        );
    }
    if (minRating) {
        filteredHospitals = filteredHospitals.filter(h => 
            h.rating >= parseFloat(minRating)
        );
    }

    // Pagination
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    const paginatedHospitals = filteredHospitals.slice(startIndex, endIndex);

    res.json({
        hospitals: paginatedHospitals,
        total_count: filteredHospitals.length,
        current_page: parseInt(page),
        total_pages: Math.ceil(filteredHospitals.length / limit)
    });
});

app.get('/api/hospitals/:id', (req, res) => {
    const hospital = hospitalData.hospitals.find(h => h.hospital_id === req.params.id);
    if (!hospital) {
        return res.status(404).json({ error: 'Hospital not found' });
    }
    res.json(hospital);
});

app.get('/api/stats', (req, res) => {
    const stats = {
        total_hospitals: hospitalData.total_count,
        states: [...new Set(hospitalData.hospitals.map(h => h.state))],
        cities: [...new Set(hospitalData.hospitals.map(h => h.city))],
        avg_rating: hospitalData.hospitals.reduce((acc, h) => acc + h.rating, 0) / hospitalData.total_count
    };
    res.json(stats);
});

// User routes
app.get('/api/user', (req, res) => {
    if (req.isAuthenticated()) {
        res.json({
            id: req.user._id,
            googleId: req.user.googleId,
            displayName: req.user.displayName,
            firstName: req.user.firstName,
            lastName: req.user.lastName,
            email: req.user.email,
            image: req.user.image
        });
    } else {
        res.status(401).json({ error: 'Not authenticated' });
    }
});

// Serve login and signup pages
app.get('/login', (req, res) => {
    if (req.isAuthenticated()) {
        return res.redirect('/dashboard');
    }
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/signup', (req, res) => {
    if (req.isAuthenticated()) {
        return res.redirect('/dashboard');
    }
    res.sendFile(path.join(__dirname, 'public', 'signup.html'));
});

app.get('/dashboard', (req, res) => {
    if (!req.isAuthenticated()) {
        return res.redirect('/login');
    }
    res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/care-connect')
    .then(() => {
        console.log('MongoDB connected');
        app.listen(PORT, () => {
            console.log(`Server is running on port ${PORT}`);
        });
    })
    .catch(err => {
        console.error('MongoDB connection error:', err);
        // Continue even if MongoDB connection fails
        app.listen(PORT, () => {
            console.log(`Server is running on port ${PORT} (without MongoDB)`);
        });
    });
